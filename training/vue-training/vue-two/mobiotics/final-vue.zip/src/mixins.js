export default {
    methods: {
        sum() {
            return 1000;
        }
    }
}