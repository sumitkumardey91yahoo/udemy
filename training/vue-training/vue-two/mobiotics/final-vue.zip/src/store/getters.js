export const getColor = (state) => {
    console.log("=======> state || gettes", state);
    return state.color
}

export const getName = (state) => {
    return state.name
}