export const setColor = (state, val) => {
    console.log("stage=====>", state)
    state.color = val;
}

export const setName = (state, val) => {
    state.name = val;
}